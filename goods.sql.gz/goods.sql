-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3309
-- Время создания: Ноя 10 2021 г., 17:53
-- Версия сервера: 5.6.51-log
-- Версия PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `goods`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) DEFAULT NULL,
  `photo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `info` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `price`, `photo`, `info`) VALUES
(1, 'Notebook', 300, 'notebook.jpg', 'This multipurpose hardbound notebook is made from unique PU cover and has hi-quality 80 gsm off-white paper. It’s enticing features include functional pocket inside, bookmark and a eleastic pen holder.\r\n\r\nSpecifications:\r\n- 80 gsm paper\r\n- 192 pages\r\n- Size: 18.6 cm x 27 cm\r\n- Colour: Brown'),
(2, 'Dairy', 289, 'dairy.jpg', 'Carry this corporate folder to your office. The black leather cover has a soft touch and makes it easy to carry anywhere. It is partitioned in five sections to arrange your work systematically. There is also a pen holder with pen at end . Rubber string acts as a lock and keeps all loose sheets and important documents in position.\r\n\r\nSpecifications:\r\n- Dimension : 22.3 cm x 18.5 cm\r\n- Colour: Black'),
(5, 'Planner', 102, 'planner.jpg', 'To plan your projects and finances this black leather planner is quite comfortable. It\'s magnetic lock with silver tag gives it good presentation. Ring binders helps to maintain the separators as per need. There are different sections for account, finance, diary and address. Pen holder at back helps to keep you from losing the pen without thinking of losing it. Card holders as well as space to carry your ID card is perfect package.\r\n\r\nSpecifications:\r\nDimensions: 24 x 19.4 cm'),
(6, 'ПЕРЬЕВАЯ РУЧКА PARKER JOTTER BLACK CT', 200, 'parkerJotterParker.jpg', 'Механизм:  с колпачком\r\n\r\nМатериал:\r\n\r\nкорпус: нержавеющая сталь, покрытая чёрным лаком\r\n\r\nдетали корпуса:нержавеющая сталь\r\n\r\nСтрана производитель: Франция'),
(7, 'ТВЕРДЫЙ БАЛЬЗАМ ДЛЯ ВОЛОС LABORATORIUM 70 Г', 700, 'tvBalzam.png', 'Типы бальзамов:\r\n1. Смягчающий (Broccoli hair balsam) (Cостав: цетеариловый спирт, бегентримониум метосульфат, репейное масло, канделильский воск, касторовое масло, глицерин, вода, масло брокколи, эфирное масло пачули, эфирное масло герани, эфирное масло лаванды, гидролизованные протеины пшеницы, бензиловый спирт, бутиленгликоль, минеральный пигмент CI 77019);\r\n2. Питательный (Muru Muru hair balsam) (Cостав: цетеариловый спирт, бегентримониум метосульфат, репейное масло, канделильский воск, касторовое масло, глицерин, пищевые ароматизаторы, вода, масло бабассу, масло муру-муру, гидролизованные протеины пшеницы, бензиловый спирт, бутиленгликоль, карамель);\r\n3. Восстанавливающий (Jojoba hair balsam) (Cостав: цетеариловый спирт, бегентримониум метосульфат, касторовое масло, канделильский воск, масло жожоба, глицерин, вода, эфирное масло корицы, эфирное масло кориандра, эфирное масло нероли, гидролизованные протеины пшеницы, бензиловый спирт, бутиленгликоль);\r\n4. Увлажняющий (Nori hair balsam) (Cостав: цетеариловый спирт, бегентримониум метосульфат, касторовое масло, канделильский воск, масло рыжика, глицерин, Nori complex (вода, глицерин, экстракт порфиры, цезальпиниевая камедь, сорбат калия, бензоат натрия), эфирное масло мяты, пищевой ароматизатор, ментол, гидролизованные протеины пшеницы, бензиловый спирт, бутиленгликоль, хлорофилл, экстракт сафлора);\r\n5. Укрепляющий (Citrus hair balsam) (Cостав: цетеариловый спирт, бегентримониум метосульфат, касторовое масло, канделильский воск, репейное масло, глицерин, вода, эфирное масло апельсина, масло арганы, эфирное масло грейпфрута, эфирное масло сандала, пищевой ароматизатор, декспантенол, гидролизованные протеины пшеницы, бензиловый спирт, бутиленгликоль, натуральный краситель CI 75120).\r\n\r\nСпособ применения: Несколько раз проведите бруском бальзама по всей длине чистых влажных волос, массажными движениями распределите бальзам по волосам, оставьте на 1-2 минуты, затем смойте водой. Просушите бальзам, прежде чем закрыть банку крышкой.'),
(8, 'ШАВЕРМА В ПИТЕ HOOD 250 Г', 180, 'shaverma.jpg', 'Состав: пита, соевое мясо в сливочном соусе, огурцы, помидоры, пекинская капуста, лук репчатый');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `no_of_order` bigint(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`no_of_order`, `user_id`, `status_id`, `date`) VALUES
(8, 4, 1, '2021-09-11 21:49:07'),
(9, 4, 1, '2021-09-11 21:56:33'),
(17, 4, 1, '2021-09-11 23:45:18'),
(18, 4, 1, '2021-09-11 23:46:49'),
(19, 4, 1, '2021-09-12 14:08:38'),
(20, 4, 1, '2021-09-14 18:12:31');

-- --------------------------------------------------------

--
-- Структура таблицы `orders_content`
--

CREATE TABLE `orders_content` (
  `no_of_order` bigint(20) NOT NULL,
  `good_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `id_useless` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders_content`
--

INSERT INTO `orders_content` (`no_of_order`, `good_id`, `quantity`, `id_useless`) VALUES
(8, 2, 1, 9),
(9, 2, 1, 12),
(9, 1, 2, 16),
(17, 2, 2, 17),
(18, 1, 2, 18),
(18, 2, 1, 19),
(18, 5, 1, 20),
(19, 1, 2, 21),
(20, 2, 1, 22);

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `orders_content_full`
-- (См. Ниже фактическое представление)
--
CREATE TABLE `orders_content_full` (
`no_of_order` bigint(20)
,`quantity` int(11)
,`title` varchar(128)
,`price` int(11)
,`photo` varchar(50)
);

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `orders_s`
-- (См. Ниже фактическое представление)
--
CREATE TABLE `orders_s` (
`no_of_order` bigint(11)
,`user_id` int(11)
,`date` datetime
,`status` varchar(100)
);

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `status`
--

INSERT INTO `status` (`id`, `status`) VALUES
(1, 'in progress'),
(2, 'delivered');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adress` text COLLATE utf8mb4_unicode_ci,
  `tel` int(11) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` int(1) DEFAULT NULL,
  `date_of_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `pass`, `adress`, `tel`, `email`, `admin`, `date_of_creation`) VALUES
(1, 'user1', 'user1', '202', NULL, 0, '', 0, '2021-08-11 13:53:42'),
(2, 'user2', 'user2', '345', NULL, 0, '', 0, '2021-08-11 17:37:26'),
(4, 'dima', 'user5', '202cb962ac59075b964b07152d234b70', 'ksksksk', 881223232, 'dima@gmail.com', 0, '2021-08-18 19:13:19'),
(5, 'dima', 'user10', '202cb962ac59075b964b07152d234b70', 'ksksksks', 2147483647, 'dima@gmail.com', NULL, '2021-08-18 19:14:53'),
(6, 'dima', 'user11', '3def184ad8f4755ff269862ea77393dd', 'ksksksk', 881234343, 'dima@gmail.com', NULL, '2021-08-18 19:18:54'),
(7, 'p', 'user13', '3def184ad8f4755ff269862ea77393dd', 'sksksk', 812, 'dima@gmail.com', NULL, '2021-08-18 19:26:16'),
(8, 'd', 's', '17e62166fc8586dfa4d1bc0e1742c08b', '3erd', 242, 'sdf@mail.com', NULL, '2021-08-18 19:33:25'),
(9, 'admin', 'admin', '', NULL, 0, '', 1, '2021-08-19 16:58:06'),
(10, 'mike', 'user100', '123', NULL, NULL, NULL, NULL, '2021-08-28 14:24:46'),
(11, 'rrr', 'user111', '698d51a19d8a121ce581499d7b701668', '', 0, '', NULL, '2021-08-28 17:18:07'),
(12, 'alex', 'user200', '202cb962ac59075b964b07152d234b70', 'slfkdlflkdkf', 9999, 'fdkgdl@gmail.com', NULL, '2021-09-07 20:11:18'),
(13, 'alex', 'user201', '202cb962ac59075b964b07152d234b70', 'fffff', 333, '333@gmail.com', NULL, '2021-09-07 20:31:02'),
(14, 'alex', 'user202', '202cb962ac59075b964b07152d234b70', 'cccc', 333, '3232@gmail.com', NULL, '2021-09-07 20:38:16'),
(15, 'alex', 'user203', '202cb962ac59075b964b07152d234b70', 'efdsdx', 3333, '333@email.com', NULL, '2021-09-07 20:41:52'),
(16, 'alex', 'user204', '202cb962ac59075b964b07152d234b70', 'skdlfs', 45242, 'dsdv@gmail.com', NULL, '2021-09-07 21:00:39');

-- --------------------------------------------------------

--
-- Структура для представления `orders_content_full`
--
DROP TABLE IF EXISTS `orders_content_full`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orders_content_full`  AS SELECT `oc`.`no_of_order` AS `no_of_order`, `oc`.`quantity` AS `quantity`, `g`.`title` AS `title`, `g`.`price` AS `price`, `g`.`photo` AS `photo` FROM (`orders_content` `oc` join `goods` `g` on((`oc`.`good_id` = `g`.`id`))) ;

-- --------------------------------------------------------

--
-- Структура для представления `orders_s`
--
DROP TABLE IF EXISTS `orders_s`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orders_s`  AS SELECT `orders`.`no_of_order` AS `no_of_order`, `orders`.`user_id` AS `user_id`, `orders`.`date` AS `date`, `status`.`status` AS `status` FROM (`orders` join `status` on((`orders`.`status_id` = `status`.`id`))) ;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`no_of_order`),
  ADD KEY `fk_user_id` (`user_id`),
  ADD KEY `fk_status_id` (`status_id`);

--
-- Индексы таблицы `orders_content`
--
ALTER TABLE `orders_content`
  ADD PRIMARY KEY (`id_useless`),
  ADD KEY `fk_no_of_order` (`no_of_order`),
  ADD KEY `fk_good_id` (`good_id`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `no_of_order` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `orders_content`
--
ALTER TABLE `orders_content`
  MODIFY `id_useless` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `orders_content`
--
ALTER TABLE `orders_content`
  ADD CONSTRAINT `fk_good_id` FOREIGN KEY (`good_id`) REFERENCES `goods` (`id`),
  ADD CONSTRAINT `fk_no_of_order` FOREIGN KEY (`no_of_order`) REFERENCES `orders` (`no_of_order`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
